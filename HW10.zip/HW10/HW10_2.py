#Testing

#Homework 10.2

import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

pi = np.pi

i = 1j
L = 1
w = 1
C = 1
Zl = 0

N = 100

Z_array = np.ndarray(N, dtype=np.complex128)

mag = np.zeros([N,N])
phase = np.zeros([N,N])

Z_array[0] = Zl
#impedence works backwards from the end
for j in range(1,N):
    Z_array[j] = Z_array[j-1] + 1/i*w*L
    Z_array[j] = 1/((1/(i*w*C))+1/Z_array[j])
    

#Z_array[-1] = Z_array[-1] - i*w*L
#flip array
Z_array = Z_array[::-1]
print(Z_array)
#make time had issue with anonymous and complex
t = np.linspace(0,2*pi, N)

V = np.ndarray([N,N], dtype=np.complex128)
I = np.ndarray([N,N], dtype=np.complex128)
#Start V and I
V[:,0] = np.cos(w*t)

I[:,0] = V[:,0]/Z_array[0]

#Compute I
for j in range(1,N):
    I[:,j] = I[:,j-1]*(1-i*w*i*C*Z_array[j])
#compute V
for j in range(1,N-1):
    V[:,j] = (I[:,j]-I[:,j+1])/(i*w*C)

print(V)
print(I)
#Get magnitudes and phases

for j in range(0,N):
    mag[:,j] = np.abs(V[:,j])
    phase[:,j] = np.angle(V[:,j])

hold = int(input('Enter which capacitor you want to see varying over time (enter only integers 0-99):'))

plt.figure()
plt.title('Magnitude',fontsize=18)
plt.xlabel(r'$Time$',fontsize=16)
plt.ylabel(r'$Magnitude of V$',fontsize=16)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.plot(t,mag[:,hold],'g')
plt.show()

plt.figure()
plt.title('Phase',fontsize=18)
plt.xlabel(r'$Time$',fontsize=16)
plt.ylabel(r'$Phase of V$',fontsize=16)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.plot(t,phase[:,hold],'r')
plt.show()