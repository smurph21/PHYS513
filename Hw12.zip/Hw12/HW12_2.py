#HW12_2

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

pi = np.pi

def dXdt3(t, X):
    T = 2 * np.pi
    # Time-dependent drivers
    U = np.array([np.cos(-2 * np.pi * t / T), 0, 0, 0 ,0])
    # Matrix A
    A = np.array([[0, 0, 0,  -1, 0],
                  [0, 0, 0, 1,  -1],
                  [0, 0, -1, 0,  1],
                  [1, -1, 0, 0, 0],
                  [0, 1,-1, 0, 0]])
    # Matrix B
    B = np.array([1, 0, 0,0,0])
    # Compute dXdt
    dXdt = A @ X + B * U
    return dXdt

# Parameters for the simulation
T = 2 * np.pi  # Period
t_span = (0, 20 * T)  # Time interval
X0 = [0, 0, 0, 0, 0]  # Initial conditions

# Solve the ODE
solution = solve_ivp(dXdt3, t_span, X0, method='RK45', t_eval=np.linspace(0, 20 * T, 500))

# Extract results
t = solution.t  # Time points
X = solution.y  # Solution array (each row corresponds to a variable)

lint = np.linspace(0,20*T,500)
V2 = 2**(1/2)*np.cos(lint+np.pi/4)
V1 = np.cos(lint-np.pi/2)

plt.figure()
#plt.plot(t,X[0])
#plt.plot(t,X[1])
#plt.plot(t,X[2])
plt.plot(t,X[3], 'g')
plt.plot(t,X[4], 'b')
plt.plot(lint,V1, 'gs')
plt.plot(lint,V2, 'bs')
#plt.legend(['I1', 'I2', 'I3', 'V1', 'V2'])
plt.legend(['V1', 'V2', 'V1ss', 'V2ss'])
plt.xlabel('t/T')
plt.show()
